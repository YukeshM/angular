export class Book {
    ISBN: number;
    BookTitle: string;
    Description: string;
    Author: string;
    price: number;
}
